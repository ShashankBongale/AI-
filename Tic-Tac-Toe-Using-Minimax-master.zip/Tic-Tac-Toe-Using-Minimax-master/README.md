# Tic-Tac-Toe-Using-Minimax
The classic tic-tac-toe game with a minimal AI using Minimax Algorithm

# How to play
Just download the [tic_tac_toe_minimax.py](https://github.com/OmkarPathak/Tic-Tac-Toe-Using-Minimax/blob/master/tic_tac_toe_minimax.py) file and open up your terminal and simply fire the command:

```python
python3 tic_tac_toe_minimax.py
```

# Screenshots

![Tic Tac Toe AI](results/tic.png)
